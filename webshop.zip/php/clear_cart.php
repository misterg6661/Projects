<?php
include('connect.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    // Töröljük a bejelentkezett felhasználó kosarát
    $sql = "DELETE FROM cart WHERE user_id = ?";
    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);

    if (mysqli_stmt_execute($stmt)) {
        echo "success";
    } else {
        echo "error";
    }
    mysqli_stmt_close($stmt);
}
?>