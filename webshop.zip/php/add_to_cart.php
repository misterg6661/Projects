<?php
include('connect.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_POST['product_id']) && isset($_SESSION['email'])) {
    $p_id = intval($_POST['product_id']);
    $email = $_SESSION['email'];

    // Mivel a tábládban az email a kulcs a user táblában
    $sql = "INSERT INTO cart (user_id, product_id, quantity) 
            VALUES ((SELECT email FROM user WHERE email = ?), ?, 1)
            ON DUPLICATE KEY UPDATE quantity = quantity + 1";

    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, "si", $email, $p_id);

    if (mysqli_stmt_execute($stmt)) {
        echo "sikeres";
    } else {
        echo "hiba";
    }
    mysqli_stmt_close($stmt);
} else {
    echo "bejelentkezes_szukseges";
}
?>