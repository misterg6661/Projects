
let menus = document.querySelector("nav");
let menuBtn = document.querySelector(".menu-btn");
let closeBTN = document.querySelector(".close-btn");

menuBtn.addEventListener("click",function (){
   menus.classList.add("active");
})

closeBTN.addEventListener("click",function (){
    menus.classList.remove("active");
})
document.querySelectorAll('.shop-item-button').forEach(button => {
    button.addEventListener('click', function() {
        const productId = this.getAttribute('data-id');

        // Adat küldése a PHP-nak
        fetch('add_to_cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `product_id=${productId}`
        })
            .then(response => response.text())
            .then(data => {
                if(data.includes("siker")) {
                    alert('Étel hozzáadva a kosárhoz!');
                    // Frissítheted itt a kosár vizuális részét is
                } else {
                    alert('Hiba történt vagy be kell jelentkezned!');
                }
            });
    });
});

