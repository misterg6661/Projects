
var gyemantok = ["Kek","Lila","Narancs","Piros","Sarga","Zold"];
var tabla =[];
var sorok = 9;
var oszlopok = 9;
var pontok = 0;
var mozgasokSzama = 0; // Számláló a játékos mozgásainak számolásához
var MAX_MOZGASOK = 25;



var aktualisMezo; //gyémánt amit mozgatunk
var masikMezo; //gyémánt amire mozgatjuk

window.onload = function() {
    // Időzítő létrehozása és indítása
    var idozito = 120; //
    var idozitoElem = document.createElement("div");
    idozitoElem.id = "idozito"; // Azonosító hozzáadása a div elemhez
    idozitoElem.innerText = "Idő: " + idozito + " mp";

    var idozitoInterval = setInterval(function() {
        idozito--; // Idő csökkentése
        idozitoElem.innerText = "Idő: " + idozito + " mp"; // Idő megjelenítése

        if (idozito <= 0) {
            clearInterval(idozitoInterval); // Időzítő leállítása
            alert("Idő lejárt! Játék vége!"); // Üzenet megjelenítése
            window.location.reload(); // Oldal újratöltése, hogy a játék ne folytatódjon
        }
    }, 1000); // 1000 ms = 1 másodperc

    // Időzítő elem hozzáadása az oldalhoz
    var cimElem = document.getElementsByTagName("h1")[0]; // Az első h1 elem kiválasztása
    cimElem.parentNode.insertBefore(idozitoElem, cimElem.nextSibling); // Időzítő beszúrása a cím után

    jatekIndul();
    // minden 1/10 mp-ben meghivja
    window.setInterval(function (){
      matchGyemant();
      leCsuszas();
      gyemantGeneral();
    }, 100)
}

function randomGyemant(){
     return gyemantok[Math.floor(Math.random() * gyemantok.length)];
}

//Legenerál random gyémántokat amiket a táblára helyez
function jatekIndul() {
    for(let s = 0; s < sorok; s++) {
        let sor = []; // ez fogja tárolni a specifikus sornak az image tagjeit
        for(let o = 0; o< oszlopok; o++) {
            let mezo = document.createElement("img");
            mezo.id = s.toString() + "-" + o.toString();
            mezo.src = "./EW4TH6/" + randomGyemant() + ".png";

            //megfogás
            mezo.addEventListener("dragstart", huzStart); //gyémántra nyomás--> elkezdi a fogó folyamatot
            mezo.addEventListener("dragover", huzAt); //miután rányomtunk a gymántra elkezdjük mozgatni a gyémántot
            mezo.addEventListener("dragenter", huzEnter); //amikor a fogott gyémántunk egy másik gyémánthoz ér
            mezo.addEventListener("dragleave", huzElhagy); // amikor elengedjük a gyémánt felett a mozgatott gyémántunkat
            mezo.addEventListener("drop",huzDobas); //elengedjuk a gyemantot a másik gyémántra
            mezo.addEventListener("dragend", huzVege); // miután kész a mozdulatunk gyémánt helyet cserél





            document.getElementById("tabla").append(mezo);
            sor.push(mezo);
        }
        tabla.push(sor);
    }
    console.log(tabla)
}
function huzStart(){
    aktualisMezo = this; // ez referál arra a gyémántra amire rányomtunk

}
function huzAt(e){
    e.preventDefault()
}
function huzEnter(e){
    e.preventDefault()
}
function huzElhagy(){

}
function huzDobas(){
    masikMezo = this; // ez referál arra mezőre amire a gyémántukat rádobjuk

}
function huzVege(){

    if(aktualisMezo.src.includes("Ures") || masikMezo.src.includes("Ures")){
        return; //nem tudunk gyémántot egy üres mezővel cserélni
    }
//csak a jobb bal fent lent levo csereje eleje
    let aktualisKordinata = aktualisMezo.id.split("-"); // id = "0-0" ebból lesz ["0","0"]
    let s = parseInt(aktualisKordinata[0]);
    let o = parseInt(aktualisKordinata[1]);
    let masikKordinata = masikMezo.id.split("-");
    let s2 = parseInt(masikKordinata[0]);
    let o2 = parseInt(masikKordinata[1]); // igy megvannak a kordináták meg kell nézni h egymás melett van a két gyémánt

    let balraHuzas = o2 == o-1 && s == s2;
    let jobbraHuzas = o2 == o+1 && s == s2;
    let felHuzas =s2 == s-1 && o == o2;
    let leHuzas = s2 == s+1 && o == o2;

    let melleteVan = balraHuzas || jobbraHuzas || felHuzas || leHuzas;
    if(melleteVan) {
        let aktualisKep = aktualisMezo.src;
        let masikKep = masikMezo.src;
        aktualisMezo.src = masikKep;
        masikMezo.src = aktualisKep; //csak a jobb bal fent lent levo csereje vege

        let legalHuzas = ellenOrzo();
        if(!legalHuzas) {
            let aktualisKep = aktualisMezo.src;
            let masikKep = masikMezo.src;
            aktualisMezo.src = masikKep;
            masikMezo.src = aktualisKep;
            var hang = document.getElementById("mozgasHang");

        }
    }
}
function matchGyemant(){
    otGyemant();
    negyGyemant();
    haromGyemant();
    document.getElementById("pontok").innerText = pontok;

}
function haromGyemant() {
    //sor megnézése
    for(let s = 0; s < sorok; s++){
        for(let o = 0; o < oszlopok-2; o++){ //-2 mivel mindig az elöző kettőt nézzük meg
            let gyemant1 = tabla[s][o];
            let gyemant2 = tabla[s][o+1];
            let gyemant3 = tabla[s][o+2];
            if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && !gyemant1.src.includes("Ures")){
                gyemant1.src ="./EW4TH6/Ures.jpg";
                gyemant2.src ="./EW4TH6/Ures.jpg";
                gyemant3.src ="./EW4TH6/Ures.jpg";
                pontok+= 30

            }
        }
    }
    // oszlop megnézése
    for (let o = 0; o < oszlopok ; o++) {
        for (let s = 0; s < sorok-2; s++) { //-2 mivel mindig az elöző kettőt nézzük meg
            let gyemant1 = tabla[s][o];
            let gyemant2 = tabla[s+1][o];
            let gyemant3 = tabla[s+2][o];
            if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && !gyemant1.src.includes("Ures")) {
                gyemant1.src = "./EW4TH6/Ures.jpg";
                gyemant2.src = "./EW4TH6/Ures.jpg";
                gyemant3.src = "./EW4TH6/Ures.jpg";
                pontok+= 30

            }
        }
    }
}
function negyGyemant() {
    // Sor ellenőrzése
    for(let s = 0; s < sorok; s++){
        for(let o = 0; o < oszlopok-3; o++){
            let gyemant1 = tabla[s][o];
            let gyemant2 = tabla[s][o+1];
            let gyemant3 = tabla[s][o+2];
            let gyemant4 = tabla[s][o+3];
            if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && gyemant3.src == gyemant4.src && !gyemant1.src.includes("Ures")){
                gyemant1.src = "./EW4TH6/Ures.jpg";
                gyemant2.src = "./EW4TH6/Ures.jpg";
                gyemant3.src = "./EW4TH6/Ures.jpg";
                gyemant4.src = "./EW4TH6/Ures.jpg";
                pontok += 40;
            }
        }
    }

    // Oszlop ellenőrzése
    for (let o = 0; o < oszlopok ; o++) {
        for (let s = 0; s < sorok-3; s++) {
            let gyemant1 = tabla[s][o];
            let gyemant2 = tabla[s+1][o];
            let gyemant3 = tabla[s+2][o];
            let gyemant4 = tabla[s+3][o];
            if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && gyemant3.src == gyemant4.src && !gyemant1.src.includes("Ures")) {
                gyemant1.src = "./EW4TH6/Ures.jpg";
                gyemant2.src = "./EW4TH6/Ures.jpg";
                gyemant3.src = "./EW4TH6/Ures.jpg";
                gyemant4.src = "./EW4TH6/Ures.jpg";
                pontok += 40;
            }
        }
    }
}

function otGyemant() {
    // Sor ellenőrzése
    for(let s = 0; s < sorok; s++){
        for(let o = 0; o < oszlopok-4; o++){
            let gyemant1 = tabla[s][o];
            let gyemant2 = tabla[s][o+1];
            let gyemant3 = tabla[s][o+2];
            let gyemant4 = tabla[s][o+3];
            let gyemant5 = tabla[s][o+4];
            if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && gyemant3.src == gyemant4.src && gyemant4.src == gyemant5.src && !gyemant1.src.includes("Ures")){
                gyemant1.src = "./EW4TH6/Ures.jpg";
                gyemant2.src = "./EW4TH6/Ures.jpg";
                gyemant3.src = "./EW4TH6/Ures.jpg";
                gyemant4.src = "./EW4TH6/Ures.jpg";
                gyemant5.src = "./EW4TH6/Ures.jpg";
                pontok += 50;
            }
        }
    }

    // Oszlop ellenőrzése
    for (let o = 0; o < oszlopok ; o++) {
        for (let s = 0; s < sorok-4; s++) {
            let gyemant1 = tabla[s][o];
            let gyemant2 = tabla[s+1][o];
            let gyemant3 = tabla[s+2][o];
            let gyemant4 = tabla[s+3][o];
            let gyemant5 = tabla[s+4][o];
            if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && gyemant3.src == gyemant4.src && gyemant4.src == gyemant5.src && !gyemant1.src.includes("Ures")) {
                gyemant1.src = "./EW4TH6/Ures.jpg";
                gyemant2.src = "./EW4TH6/Ures.jpg";
                gyemant3.src = "./EW4TH6/Ures.jpg";
                gyemant4.src = "./EW4TH6/Ures.jpg";
                gyemant5.src = "./EW4TH6/Ures.jpg";
                pontok += 50;
            }
        }
    }
}

function ellenOrzo(){
for(let s = 0; s < sorok; s++){
    for(let o = 0; o < oszlopok-2; o ++){ //-2 mivel mindig az elöző kettőt nézzük meg
        let gyemant1 = tabla[s][o];
        let gyemant2 = tabla[s][o+1];
        let gyemant3 = tabla[s][o+2];
        if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && !gyemant1.src.includes("Ures")){
            return true;

        }
    }
}
// oszlop megnézése
for (let o = 0; o < oszlopok ; o++) {
    for (let s = 0; s < sorok-2; s++) { //-2 mivel mindig az elöző kettőt nézzük meg
        let gyemant1 = tabla[s][o];
        let gyemant2 = tabla[s+1][o];
        let gyemant3 = tabla[s+2][o];
        if(gyemant1.src == gyemant2.src && gyemant2.src == gyemant3.src && !gyemant1.src.includes("Ures")) {
           return true;
        }
    }
}
return false;
}
function leCsuszas(){
    for(let o = 0; o < oszlopok; o++){
        let index = sorok-1;
        for(let s = oszlopok-1; s>= 0 ; s--){
            if(!tabla[s][o].src.includes("Ures")){
                tabla[index][o].src = tabla[s][o].src;
                index -= 1;

            }
        }
        for(let s = index; s >= 0 ; s--){
            tabla[s][o].src = "./EW4TH6/Ures.jpg";
        }
    }
}
function gyemantGeneral(){ // csak az első sorban generalunk
    for (let o = 0; o < oszlopok ; o++) {
        if(tabla[0][o].src.includes("Ures")){
            tabla[0][o].src = "./EW4TH6/" + randomGyemant() + ".png";
        }
    }
}



