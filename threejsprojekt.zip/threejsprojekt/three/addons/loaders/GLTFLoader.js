export class GLTFLoader {

}