from zaszlo import zaszlo, zaszlo_leszed, megjelolve


#zaszlo függveny teszt
def test_zaszlo_megjelol():
    flagged = [[False, False],
               [False, False]] # 0 0, 0 1, 1 0, 1 1 ( 2x2 matrix) minden mező false = nincs flag
    zaszlo(flagged, 1 , 1)
    assert flagged[1][1] == True # ha true meg lett jelolve

#zaszlo_leszed teszt
def test_zaszlo_leszed():
    flagged = [[True, True],
               [True, True]] #minden mező true tehat van rajta zaszlo
    zaszlo_leszed(flagged, 1 , 1)
    assert flagged[1][1] == False #ha false levette a zaszlot

#zaszlozott mezot fellehet-e fedni teszt
def test_zaszlozott_felfedes():
    flagged = [[False, False],
               [False, False]] #nincs zaszlo
    uncovered = [[False, False],
                 [False, False]] #nincs felfedve egy mezo se
    zaszlo(flagged, 1 , 1) # zaszlo az 1 1 poziciora
    if megjelolve(flagged, 1, 1): # 1 1 mezo "felfedese"
        print("már van rajta zaszlo")
    uncovered[1][1] = False
    assert uncovered[1][1] == False
