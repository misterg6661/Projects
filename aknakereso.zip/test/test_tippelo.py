from tippelo import tipp_generalas

# add e tippet ha nincs biztonsagos mező (csak akna van)
def test_tippgeneralas_nincsbiztonsagos_mezo():
    field = [["X", "X"],
             ["X", "X"]] #2x2-ön tesztelünk
    flagged = [[False, False],
               [False, False]]  # nincs zaszlo
    uncovered = [[False, False],
                 [False, False]] #nincs felfedés

    tipp = tipp_generalas(field, flagged, uncovered)
    assert tipp is None;

# zaszloval jelolt mezőt felfed e a tipp
def test_tippgeneralas_zaszlo_kerulo():
    field = [["0", "x"],
             ["x", "0"]]
    uncovered = [[False, False],
                 [False, False]]
    flagged = [[False, True],
               [False, False]]

    tipp = tipp_generalas(field, flagged, uncovered)
    assert tipp != (0,1)
    assert tipp in [(0,0), (1,1)] # (1,0) ha benne van soha nem fogja visszaadni miven akna

#komplikaltabb tippgeneralas
def test_tipp_generalas_komplikalt():
    field = [["0", "X", "B"],
             ["0", "0", "X"],
             ["B", "X", "0"]] #B = felvan fedve és nem akna
    uncovered = [[False, False, True],
                 [False, False, False],
                 [True, False, False]]
    flagged = [[False, True, False],
               [False, True, False],
               [ False, False, False]]
    tipp = tipp_generalas(field, flagged, uncovered)
    nemValaszthato = [
        (0,2), #felfedett
        (2,0), #felfedett
        (0,1), #zaszlos
        (1,1) #zaszlos
                      ]
    valaszthato =[(0,0), (1,0), (2,2)]
    assert tipp not in nemValaszthato
    assert tipp in valaszthato