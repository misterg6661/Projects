import random

def tipp_generalas(field, uncovered, flagged):
    rows = len(field)
    cols = len(field[0])
    biztonsagos_tippek = []

    for i in range(rows):
        for j in range(cols):
            if not uncovered[i][j] and not flagged[i][j] and field[i][j] != "X":
                biztonsagos_tippek.append((i, j))

    return random.choice(biztonsagos_tippek) if biztonsagos_tippek else None
