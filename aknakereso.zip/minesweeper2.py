import random
from zaszlo import create_flagged_grid, zaszlo, zaszlo_leszed, megjelolve
from tippelo import tipp_generalas

def create_playing_field():
    # Aknahelyek véletlenszerű elhelyezése
    mines = 40
    playing_field = []
    for i in range(21):
        field_line = ["0"] * 12  # Üres mezők
        playing_field.append(field_line)

    for _ in range(mines):
        while True:
            rand_i = random.randint(0, 20)
            rand_j = random.randint(0, 11)
            if playing_field[rand_i][rand_j] == "0":
                playing_field[rand_i][rand_j] = "X"
                break
    return playing_field

def calculate_numbers(field):
    # Akna körüli számok számítása
    rows = len(field)
    cols = len(field[0])
    new_field = []
    for i in range(rows):
        new_row = []
        for j in range(cols):
            if field[i][j] == "X":
                new_row.append("X")
            else:
                count = 0
                for di in (-1, 0, 1):
                    for dj in (-1, 0, 1):
                        if di == 0 and dj == 0:
                            continue
                        ni, nj = i + di, j + dj
                        if 0 <= ni < rows and 0 <= nj < cols:
                            if field[ni][nj] == "X":
                                count += 1
                new_row.append(str(count))
        new_field.append(new_row)
    return new_field

def display_uncovered_field(field, uncovered, flagged):
    # Kiírja a táblát az állapotokkal (fedett, felfedett, megjelölt)
    header = "   " + "  ".join(str(j) for j in range(len(field[0])))
    print(header)
    for i in range(len(field)):
        row_str = str(i).ljust(3)
        for j in range(len(field[0])):
            if uncovered[i][j]:
                row_str += field[i][j].ljust(3)
            elif flagged[i][j]:
                row_str += " F ".ljust(3)  # Megjelölt cellák
            else:
                row_str += "   "  # Fedett cellák
        print(row_str)

def get_user_move(rows, cols):
    while True:
        user_input = input("Add meg a felfedendő cella sorát és oszlopát (vagy ha zászlót szeretnél rakni/levenni akkor az elejére: \n flag (f) / unflag (uf) parancs, vagy tippeléshez 'h'): ").strip()
        if user_input.lower() == 'h':
            return "tipp", None, None
        elif user_input.lower().startswith("f") or user_input.lower().startswith("uf"):
            parts = user_input.split()
            if len(parts) != 3:
                print("Kérlek, pontosan három paramétert adj meg!")
                continue
            try:
                command = parts[0].lower()
                row = int(parts[1])
                col = int(parts[2])
            except ValueError:
                print("Hibás bemenet. Kérlek számokat adj meg.")
                continue
            if not (0 <= row < rows and 0 <= col < cols):
                print("A megadott koordináták kívül esnek a tábla határain. Próbáld újra.")
                continue
            return command, row, col
        else:
            parts = user_input.split()
            if len(parts) != 2:
                print("Kérlek, pontosan két számot adj meg szóközzel elválasztva!")
                continue
            try:
                row = int(parts[0])
                col = int(parts[1])
            except ValueError:
                print("Hibás bemenet. Kérlek egész számokat adj meg.")
                continue
            if not (0 <= row < rows and 0 <= col < cols):
                print("A megadott koordináták kívül esnek a tábla határain. Próbáld újra.")
                continue
            return "reveal", row, col

def game_loop(numbered_field):
    rows = len(numbered_field)
    columns = len(numbered_field[0])
    uncovered = [[False for _ in range(columns)] for _ in range(rows)]
    flagged = create_flagged_grid(rows, columns)

    max_tipp = 3
    tipp_szamlalo = 0

    while True:
        display_uncovered_field(numbered_field, uncovered, flagged)
        print(f"Ennyi tipp maradt: {max_tipp - tipp_szamlalo}")
        move_type, row, col = get_user_move(rows, columns)

        if move_type == "tipp":
            if tipp_szamlalo >= max_tipp:
                print("Elfogyott a tipp bástya!")
                continue

            # Tippelés logika: véletlenszerűen választunk egy biztonságos cellát
            tipp = tipp_generalas(numbered_field, uncovered, flagged)
            if tipp:
                i, j = tipp
                uncovered[i][j] = True
                print(f"🔍 Tipp: A {i} {j} felfedve.")
                tipp_szamlalo += 1
            else:
                print("Nincs több biztonságos mező.")
            continue

        if move_type == "f":
            if uncovered[row][col]:
                print(" Ez a mező már fel van fedve, nem lehet megjelölni!")
                continue
            zaszlo(flagged, row, col)

        elif move_type == "uf":
            if uncovered[row][col]:
                print(" Ez a mező már fel van fedve, nincs rajta zászló!")
                continue
            zaszlo_leszed(flagged, row, col)

        elif move_type == "reveal":
            if megjelolve(flagged, row, col):
                print("Ez a cella meg van jelölve, szedd le a zászlót!")
                continue

            uncovered[row][col] = True
            if numbered_field[row][col] == "X":
                display_uncovered_field(numbered_field, uncovered, flagged)
                print("Aknára léptél, vége a játéknak!")
                for i in range(rows):
                    for j in range(columns):
                        uncovered[i][j] = True

                display_uncovered_field(numbered_field, uncovered, flagged)
                break

            if check_win_condition(numbered_field, uncovered):
                display_uncovered_field(numbered_field, uncovered, flagged)
                print("Gratulálok! Minden biztonságos cellát felfedtél!")
                break

def check_win_condition(field, uncovered):
    rows = len(field)
    cols = len(field[0])
    for i in range(rows):
        for j in range(cols):
            if field[i][j] != "X" and not uncovered[i][j]:
                return False
    return True

def main():
    playing_field = create_playing_field()
    numbered_field = calculate_numbers(playing_field)
    print("Üdvözlünk az Akna-kereső játékban!")
    game_loop(numbered_field)

if __name__ == "__main__":
    main()
