

def create_flagged_grid(rows, cols):
    return [[False for _ in range(cols)] for _ in range(rows)]

def zaszlo(flagged, row, col):
    if flagged[row][col]:
        print(f"A({row}, {col}) cellán már van zászló!")
    else:
        flagged[row][col] = True
        print(f"A({row}, {col}) cella bezászlózva!")

def zaszlo_leszed(flagged, row, col):
    if not flagged[row][col]:
        print(f"A({row}, {col}) cellán nincs zászló nincs mit levenni sajnos:(!")
    else:
        flagged[row][col] = False
        print(f"A({row}, {col}) levettem a celláról a zászlót!")

def megjelolve(flagged, row, col):
    return flagged[row][col]
